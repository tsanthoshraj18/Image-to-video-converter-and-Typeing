const paragraphs = [
   "Ulaanbaatar is the capital of Mongolia and its largest city.As a nomadic city,the capital used to move three times a year. With just four people per square mile, Mongolia is tht least densety populated country on Earth    . "
];